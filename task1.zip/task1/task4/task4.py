import numpy as np


def maxn_nvec(x):  # I вариант - без векторизации
    my_list = []
    for i in range(len(x)-1):
        if x[i] == 0:
            my_list.append(x[i+1])
    return max(my_list)


def maxn_vec(x):  # II вариант - с векторизацией
    indices = np.where(x == 0)
    indices += np.ones(len(indices))
    indices = indices[indices < len(x)]
    return max(x[indices.astype(np.int64)])


def maxn_hybr(x):  # III вариант - гибридная реализация
    max_val = 0
    was_found = False
    for i in range(1, len(x)):
        if x[i-1] == 0:
            if x[i] > max_val or was_found is False:
                max_val = x[i]
                was_found = True

    return max_val
