import numpy as np


def img_nvec(img, w_vec):  # I вариант - без векторизации
    sz_x = len(img)
    sz_y = len(img[0])
    sz_z = len(img[0][0])
    res_matrix = np.zeros((sz_x, sz_y))
    for z in range(sz_z):
        for x in range(sz_x):
            for y in range(sz_y):
                res_matrix[x][y] += img[x][y][z] * w_vec[z]

    return res_matrix


def img_vec(img, w_vec):  # II вариант - с векторизацией
    return np.tensordot(img, w_vec, axes=(1))


def img_hybr(img, w_vec):  # III вариант - гибридная реализация
    sz_x = len(img)
    sz_y = len(img[0])
    res_matrix = np.zeros((sz_x, sz_y))
    for x in range(sz_x):
        for y in range(sz_y):
            res_matrix[x][y] = np.dot(img[x][y], w_vec)
    return res_matrix
