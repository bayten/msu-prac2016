import numpy as np
import math


def cdst_nvec(X, Y):  # I вариант - без векторизации
    len_x = len(X)
    len_y = len(Y)
    len_n = len(X[0])

    ret_mat = []

    for x in range(len_x):
        new_dists = []
        for y in range(len_y):
            total_mul = 0.0
            for n in range(len_n):
                total_mul += (X[x][n]-Y[y][n])**2
            new_dists.append(math.sqrt(total_mul))
        ret_mat.append(new_dists)
    return ret_mat


def cdst_vec(X, Y):  # II вариант - с векторизацией
    normed_squares = (np.linalg.norm(Y[:, np.newaxis], axis=2)**2).T + \
                      np.linalg.norm(X[:, np.newaxis], axis=2)**2
    return np.sqrt(normed_squares - 2*np.dot(X, Y.T))


def cdst_hybr(X, Y):  # III вариант - гибридная реализация
    res_mat = np.zeros((len(X), len(Y)))

    for idx, x in enumerate(X):
        for idy, y in enumerate(Y):
            res_mat[idx][idy] = np.sqrt(np.sum((x-y)**2))
    return res_mat
