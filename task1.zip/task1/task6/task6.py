import numpy as np


def rle_nvec(x):  # I вариант - без векторизации
    l_vals = []
    l_reps = []
    cur_val = x[0]
    cur_rep = 0

    for value in x:
        if value == cur_val:
            cur_rep += 1
        else:
            l_vals.append(cur_val)
            l_reps.append(cur_rep)
            cur_val = value
            cur_rep = 1
    l_vals.append(cur_val)
    l_reps.append(cur_rep)
    return (np.array(l_vals), np.array(l_reps))


def rle_vec(x):  # II вариант - с векторизацией
    diffs = np.append(np.where(x[1:] != x[:-1]), len(x)-1)  # differ places
    reps = np.diff(np.append(-1, diffs))
    vals = x[np.cumsum(np.append(0, np.array(reps)))[:-1]]
    return (vals, reps)


def rle_hybr(x):  # III вариант - гибридная реализация
    diffs = np.append(np.where(x[1:] != x[:-1]), len(x)-1)
    reps = np.diff(np.append(-1, diffs))
    vals = []

    diffs += np.ones(len(diffs)).astype(np.int64)
    for i in np.append(0, diffs[:-1]):
        vals.append(x[i])

    return (vals, reps)
