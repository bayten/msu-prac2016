import numpy as np


def build_nvec(X, i, j):  # I вариант - без векторизации
    res_vec = np.zeros((len(i)))
    for index in range(len(i)):
        res_vec[index] = X[i[index]][j[index]]

    return res_vec


def build_vec(X, i, j):  # II вариант - с векторизацией
    return np.array(X)[i, j]


def build_hybr(X, i, j):  # III вариант - гибридная реализация
    all_indices = [(i[x], j[x]) for x in range(len(i))]
    X = np.array(X)

    return np.array([X[all_indices[x]] for x in range(len(i))])
