import numpy as np


def diagmul_nvec(X):  # I вариант - без векторизации
    min_sz = min(len(X), len(X[0]))
    total = 1
    for i in range(min_sz):
        if X[i][i] != 0:
            total *= X[i][i]

    return total


def diagmul_vec(X):  # II вариант - с векторизацией
    diag_arr = np.diag(np.array(X))
    return np.prod(diag_arr[diag_arr != 0])


def diagmul_hybr(X):  # III вариант - гибридная реализация
    diag_arr = np.diag(np.array(X))
    diag_arr = diag_arr[diag_arr != 0]
    total = 1
    for i in range(len(diag_arr)):
        total *= diag_arr[i]

    return total
