import math
import numpy as np


def lpdf_nvec(X, m, C):  # I вариант - без векторизации
    dim = len(X[0])
    invC = np.linalg.inv(C)
    log_coeff = math.log(np.linalg.det(C) * (2*math.pi)**dim)
    for xitem in X:
        for i in range(dim):
            xitem[i] -= m[i]

    total_vec = []
    for xitem in X:
        total_sum = 0.0
        for i in range(dim):
            dot_sum = 0.0
            for j in range(dim):
                dot_sum += xitem[j] * invC[i][j]
            total_sum += dot_sum * xitem[i]
        total_vec.append(-0.5 * (total_sum + log_coeff))

    return total_vec


def lpdf_vec(X, m, C):  # II вариант - с векторизацией
    dim = len(X[0])
    invC = np.linalg.inv(C)
    dmat = X-m
    exp_part = np.matmul(np.matmul(dmat, invC), dmat.T)
    log_part = np.log(np.linalg.det(C) * (2*math.pi)**dim)
    return np.diag(-0.5 * (log_part + exp_part))


def lpdf_hybr(X, m, C):  # III вариант - гибридная реализация
    dim = len(X[0])
    invC = np.linalg.inv(C)
    log_coeff = math.log(np.linalg.det(C) * (2*math.pi)**dim)
    X = X-m

    total_vec = []
    for xitem in X:
        total_sum = 0.0
        for i in range(dim):
            dot_sum = 0.0
            for j in range(dim):
                dot_sum += xitem[j] * invC[i][j]
            total_sum += np.dot(xitem, invC[i]) * xitem[i]
        total_vec.append(-0.5 * (total_sum + log_coeff))

    return total_vec
