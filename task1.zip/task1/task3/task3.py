import numpy as np


def mset_nvec(x, y):  # I вариант - без векторизации
    if sorted(x) == sorted(y):
        return True
    return False


def mset_vec(x, y):  # II вариант - с векторизацией
    return np.array_equal(np.sort(x), np.sort(y))


def mset_hybr(x, y):  # III вариант - гибридная реализация
    if len(x) != len(y):
        return False

    x_dict = {}
    y_dict = {}

    for i in range(len(x)):
        if x_dict.get(x[i]) is not None:
            x_dict[x[i]] += 1
        else:
            x_dict[x[i]] = 1

        if y_dict.get(y[i]) is not None:
            y_dict[y[i]] += 1
        else:
            y_dict[y[i]] = 1

    return x_dict.items() == y_dict.items()
